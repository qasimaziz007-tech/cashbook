@echo off
title Esthetics Auto CashBook
cd /d "%~dp0"
set "HTML_PATH=%CD%\index.html"
set "FILE_URL=file:///%HTML_PATH:\=/%"

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%FILE_URL%" --new-window
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="%FILE_URL%" --new-window  
) else if exist "%ProgramFiles%\Mozilla Firefox\firefox.exe" (
    start "" "%ProgramFiles%\Mozilla Firefox\firefox.exe" --new-window "%FILE_URL%"
) else (
    start "" "index.html"
)
