Set WshShell = CreateObject("WScript.Shell")
WshShell.Run Chr(34) & "CashBook.bat" & Chr(34), 0
Set WshShell = Nothing
