@echo off
setlocal
title Esthetics Auto CashBook - Professional Financial Management

REM Set application info
set APP_NAME=Esthetics Auto CashBook
set VERSION=1.0.0

REM Get current directory and HTML file path
cd /d "%~dp0"
set "HTML_PATH=%CD%\index.html"
set "FILE_URL=file:///%HTML_PATH:\=/%"

REM Check if HTML file exists
if not exist "%HTML_PATH%" (
    echo Error: Application file not found!
    echo Please ensure index.html is in the same directory as this launcher.
    pause
    exit /b 1
)

echo Starting %APP_NAME% v%VERSION%...
echo.

REM Try different browsers in order of preference
echo Detecting browser...

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    echo Found: Google Chrome (64-bit)
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" ^
        --app="%FILE_URL%" ^
        --new-window ^
        --disable-web-security ^
        --window-size=1400,900 ^
        --window-position=100,100
    goto :launched
)

if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    echo Found: Google Chrome (32-bit)
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" ^
        --app="%FILE_URL%" ^
        --new-window ^
        --disable-web-security ^
        --window-size=1400,900 ^
        --window-position=100,100
    goto :launched
)

if exist "%ProgramFiles%\Mozilla Firefox\firefox.exe" (
    echo Found: Mozilla Firefox
    start "" "%ProgramFiles%\Mozilla Firefox\firefox.exe" ^
        --new-window "%FILE_URL%"
    goto :launched
)

if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    echo Found: Microsoft Edge
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" ^
        --app="%FILE_URL%" ^
        --new-window
    goto :launched
)

REM Fallback to default browser
echo No specific browser found - using default browser
start "" "%HTML_PATH%"

:launched
echo.
echo %APP_NAME% launched successfully!
echo Login with: admin / admin123
echo.
timeout /t 3 /nobreak >nul
exit /b 0
