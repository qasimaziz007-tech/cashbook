' Esthetics Auto CashBook - Silent Launcher for Windows
' Professional Financial Management System

Dim WshShell, AppPath, BatchFile, Result

Set WshShell = CreateObject("WScript.Shell")

' Get current directory
AppPath = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))
BatchFile = AppPath & "CashBook.bat"

' Check if batch file exists
Dim FileSystem
Set FileSystem = CreateObject("Scripting.FileSystemObject")

If FileSystem.FileExists(BatchFile) Then
    ' Launch the batch file silently
    Result = WshShell.Run(Chr(34) & BatchFile & Chr(34), 0, False)
Else
    ' Show error message
    MsgBox "Error: CashBook.bat not found!" & vbCrLf & vbCrLf & _
           "Please ensure all files are in the same directory.", _
           vbCritical, "Esthetics Auto CashBook"
End If

Set WshShell = Nothing
Set FileSystem = Nothing
