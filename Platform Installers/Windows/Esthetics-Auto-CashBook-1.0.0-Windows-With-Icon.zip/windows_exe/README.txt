Esthetics Auto CashBook v1.0.0
=======================

Professional CashBook Management System for Esthetics Auto

INSTALLATION:
1. Extract all files to a folder (e.g., C:\Program Files\Esthetics Auto CashBook\)
2. Double-click CashBook.vbs for silent launch
3. Or double-click CashBook.bat for console launch

LOGIN:
Username: admin
Password: admin123

FEATURES:
- Complete transaction management
- Employee and payroll system  
- Advanced analytics and reports
- Auto backup and data export
- Works completely offline

CUSTOM ICON:
This package includes the official Esthetics Auto icon
- Blue gradient design with gear and circuit elements
- Professional branding for desktop integration

SYSTEM REQUIREMENTS:
- Windows 7 SP1 or later
- Modern browser (Chrome, Firefox, Edge)
- 50MB free disk space

SUPPORT:
Email: qasimaziz007@gmail.com
Website: https://qasimaziz007-tech.github.io/cashbook/

© 2024 Esthetics Auto - Made with ❤️ by Qasim Aziz
