Esthetics Auto CashBook - Portable Windows Version
=====================================

HOW TO USE:
1. Double-click "CashBook.vbs" to launch
2. Login: admin / admin123
3. Works completely offline

FEATURES:
- Complete transaction management
- Employee and payroll system
- Analytics and reports
- Auto backup system

SYSTEM REQUIREMENTS:
- Windows 7 or later
- Any modern browser (Chrome recommended)

SUPPORT: qasimaziz007@gmail.com

Made with ❤️ by Qasim Aziz
