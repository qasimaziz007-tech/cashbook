@echo off
title Esthetics Auto CashBook
cd /d "%~dp0"

REM Try Chrome first (best app mode)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="file:///%CD%/index.html" --new-window
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="file:///%CD%/index.html" --new-window
) else (
    start "" "index.html"
)
